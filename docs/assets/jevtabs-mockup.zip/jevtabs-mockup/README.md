# JevTabs interactive mockup

A high-fidelity desktop prototype for a browser intent workspace. It models a browser-native capture layer, a workspace-grade review surface, and an agent-ready context flow.

## Included flows

- Today: inferred active thread, foreground visits, ignored ambient tabs
- Activity Inbox: low-confidence classification review
- Research Threads: active, dormant, and reactivated work
- Thread detail: intent, findings, open questions, provenance, agent activity
- Agent Context: token-budgeted context pack and permissions
- Checkpoint modal: save and pause work when an activity shift is detected

## Run locally

Open `index.html` directly in a browser, or serve the folder:

```bash
python3 -m http.server 4173 --directory jevtabs-mockup
```

Then open `http://127.0.0.1:4173`.

No package installation or build step is required.
