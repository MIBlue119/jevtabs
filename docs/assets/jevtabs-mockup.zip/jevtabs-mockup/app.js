const views = [...document.querySelectorAll('.view')];
const navItems = [...document.querySelectorAll('.nav-item')];

function showView(name) {
  views.forEach(view => view.classList.toggle('active', view.id === `view-${name}`));
  navItems.forEach(item => item.classList.toggle('active', item.dataset.view === name));
  document.querySelector('.content-area').scrollTop = 0;
}

document.querySelectorAll('[data-view]').forEach(button => {
  button.addEventListener('click', () => showView(button.dataset.view));
});

document.querySelectorAll('[data-view-target]').forEach(button => {
  button.addEventListener('click', () => showView(button.dataset.viewTarget));
});

document.querySelectorAll('.choice').forEach(choice => {
  choice.addEventListener('click', () => {
    choice.closest('.choice-list').querySelectorAll('.choice').forEach(item => item.classList.remove('selected'));
    choice.classList.add('selected');
  });
});

const modal = document.getElementById('checkpointModal');
document.getElementById('checkpointBtn').addEventListener('click', () => modal.classList.add('show'));
document.getElementById('closeModal').addEventListener('click', () => modal.classList.remove('show'));
document.getElementById('notNow').addEventListener('click', () => modal.classList.remove('show'));
modal.addEventListener('click', event => { if (event.target === modal) modal.classList.remove('show'); });

const toast = document.getElementById('toast');
function showToast(title, message) {
  toast.querySelector('strong').textContent = title;
  toast.querySelector('small').textContent = message;
  toast.classList.add('show');
  clearTimeout(window.toastTimer);
  window.toastTimer = setTimeout(() => toast.classList.remove('show'), 2800);
}

document.getElementById('saveCheckpoint').addEventListener('click', () => {
  modal.classList.remove('show');
  showToast('Checkpoint 已建立', 'Thread 已暫停；相關活動再次出現時會提醒你。');
});
document.getElementById('confirmCurrent').addEventListener('click', event => {
  event.currentTarget.textContent = '✓ 已確認';
  showToast('推論已確認', '這次選擇會改善之後的 Thread 判斷。');
});
document.querySelectorAll('.resolve-btn').forEach(button => button.addEventListener('click', event => {
  const card = event.currentTarget.closest('.decision-card');
  card.style.opacity = '.45';
  card.style.pointerEvents = 'none';
  showToast('已歸類到 Perceptron eval', 'Activity Inbox 還有 3 筆待確認。');
}));
document.getElementById('acceptAll').addEventListener('click', () => showToast('已接受 2 筆高信心建議', '低信心活動仍保留給你判斷。'));
document.getElementById('sendAgent').addEventListener('click', event => {
  event.currentTarget.textContent = '✓ Claude Code 已啟動';
  showToast('Context Pack 已送出', 'Claude Code 已取得 6,184 tokens 與 6 個來源摘錄。');
});

const tokenRange = document.getElementById('tokenRange');
const tokenLabel = document.getElementById('tokenLabel');
const contextValues = {
  1: ['Brief · 約 2,000 tokens', '2,140 estimated tokens'],
  2: ['Evidence · 約 6,000 tokens', '6,184 estimated tokens'],
  3: ['Full trace · 約 14,000 tokens', '14,420 estimated tokens']
};
tokenRange.addEventListener('input', () => {
  tokenLabel.textContent = contextValues[tokenRange.value][0];
  document.querySelector('.preview-head strong').textContent = contextValues[tokenRange.value][1];
});

document.addEventListener('keydown', event => {
  if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === 'k') {
    event.preventDefault();
    document.getElementById('globalSearch').focus();
  }
  if (event.key === 'Escape') modal.classList.remove('show');
});
